package CollectionComparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sort {
public static void main(String[] args) {
	List<String>l=new ArrayList<String>();
	l.add("soma");
	l.add("rohith");
	Collections.sort(l);
	System.out.println(l);
	
}
}
