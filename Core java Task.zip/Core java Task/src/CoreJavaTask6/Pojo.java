package CoreJavaTask6;

public class Pojo {
	
	public String name , address;
	int id ;
	
	public void pojo(String name , String address , int id) {
		
		this.name= name;
		this.id = id;
		this.address = address;
		
	}

}
