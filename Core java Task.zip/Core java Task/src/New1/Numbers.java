package New1;

//Print 1 To 100 without Using Number

public class Numbers {
	public static void main(String args[]) {
		
		int one = 'a' / 'a';
		int ten = "**********".length();
		
		for(int i = one; i <=(ten*ten); i++) {
			System.out.println(i);
		}
		
	}

}
