package New1;

public interface Operation {
	
	public int opt(int x , int y);

}
