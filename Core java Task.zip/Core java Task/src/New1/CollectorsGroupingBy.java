package New1;

import java.util.ArrayList;
import java.util.List;
import java.util.*;

public class CollectorsGroupingBy {

	public static void main(String args []) {
		
//		List<Person>personalList = new ArrayList();
//		
//
//		personalList.add(new Person("Soma" , "Kolkata" , 25));
//		personalList.add(new Person("Surovita" , "Pune" , 25));
//		personalList.add(new Person("Sourav" , "Pune" , 25));
//		personalList.add(new Person("Sanu" , "Kolkata" , 25));
//		personalList.add(new Person("Sholanki" , "Bangalore" , 25));
//		personalList.add(new Person("Sabarna" , "Hyderabad" , 25));
//		personalList.add(new Person("Sandipa" , "Kolkata" , 25));
//		personalList.add(new Person("Shounak" , "Hyderabad" , 25));
//		
//		Map<String.List<Person>>groupByCity = personalList.Stream().collect(collector.groupingBy(Person::getCity));
		
		
	} 

}
