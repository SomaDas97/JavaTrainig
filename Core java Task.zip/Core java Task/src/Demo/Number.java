package Demo;

public interface Number {
	void show() ;

}

