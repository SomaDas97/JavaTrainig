package Demo;

public class Display {
	public static void main(String args []) {
		Number n = new NumberImp();
		n.show();
		
	}

}
