package Demo;

public class NumberImp implements Number {

	@Override
	public void show() {
	System.out.println("1");
		
	}
	

}
