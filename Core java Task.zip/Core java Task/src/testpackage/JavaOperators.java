package testpackage;

public class JavaOperators {
	public static void main(String args[]) {
		int a = 20;
		int b = 5;
		System.out.println("The sum is " + (a+b));
		System.out.println("The sum is " + (a-b));
		System.out.println("The sum is " + (a/b));
		System.out.println("The sum is " + (a%b));
	}

}
