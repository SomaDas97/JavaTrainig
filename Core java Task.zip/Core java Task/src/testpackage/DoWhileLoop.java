package testpackage;

public class DoWhileLoop {
	public static void main(String args[]) {
		int a = 0;
		do {
			System.out.println(a);
			a++;
		} while(a<11);
	}
}
