package testpackage;

public class ForLoop1 {

}
