package testpackage;

public class ForLoop {
	public static void main(String[] args) {
		int a = 100;
		for(int i =0; i<=a; i++)
		{
			if(i==10) {
			System.out.println(i);
			
		}
			
	}
	}
}

