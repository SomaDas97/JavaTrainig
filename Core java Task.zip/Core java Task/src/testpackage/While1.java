package testpackage;

public class While1 {
	public static void main(String args[]) {
		int a = 0;
		while(a < 11) {
			System.out.println(a);
			a++;
		}
	}

}
