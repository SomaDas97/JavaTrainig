package testpackage;

public class ForDemo {
	public static void main(String args[]) {
		for(int a=1; a<=10; a++) {
			System.out.println(a);
		}
	}

}
