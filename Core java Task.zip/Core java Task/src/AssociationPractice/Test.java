package AssociationPractice;
import java.util.*;
public class Test {

}
