package CoreJavaTaskNo5;

public class Box3d extends Box{
	
    void area(double length , double bredth) {
    	
    	System.out.println(length*bredth);
    }
    
    void volume(double length , double bredth , double height) {
    	
    	System.out.println(length * bredth * height);
    }

}
