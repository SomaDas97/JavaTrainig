package CoreJavaTaskNo5;

public class Box {
	
	public void Square() {
	}

}
