package CoreJavaTaskNo5;

public class Result {
	
	public static void main (String args []) {
		
		Box3d b = new Box3d();
		b.area(1, 3);
		b.volume(4,3,2);
		
		
	}

}
