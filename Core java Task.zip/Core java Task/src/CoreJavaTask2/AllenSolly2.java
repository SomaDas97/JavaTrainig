package CoreJavaTask2;

public class AllenSolly2 {
	
	public static void main(String args []) {
		
		NewShopping n = new NewShopping();
		n.Jeans();
	}

}
