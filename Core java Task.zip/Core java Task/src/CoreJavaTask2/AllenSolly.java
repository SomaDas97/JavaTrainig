package CoreJavaTask2;

public class AllenSolly {
	
	public void Jeans() {
		System.out.println("Denim Jeans");
	}
}

class NewShopping extends AllenSolly{
	
	public void NewJeans() {
		System.out.println("Ripped Jeans");
	}
}

