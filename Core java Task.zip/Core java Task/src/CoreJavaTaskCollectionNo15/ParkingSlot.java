/*parking slots
1. there are two basements b1 and b2 both contains 30 slots
2. b1 for bikes and b2 for cars
3. allocate a vehicles with slots and generate a receipt and don't allocate a single slot for two vehicles
4. and store the data in a file*/

package CoreJavaTaskCollectionNo15;

import java.util.HashMap;

public class ParkingSlot {
	
	public static void main(String args[]) {
		
		HashMap<Integer , String> b1 = new HashMap<Integer , String>();
		
	}

}
