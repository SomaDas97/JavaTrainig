package AbstractJava;
import java.util.*;
public class NewCollections {
public static void main(String args[]) {
	ArrayList<Integer> al=new ArrayList<>();
}
}
