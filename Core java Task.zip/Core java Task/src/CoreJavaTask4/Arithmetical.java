package CoreJavaTask4;

public class Arithmetical implements Test  {

	@Override
	public double square(double x) {
		
		double sq =x*x;
		
		
		return sq;
	}
	
	

}
