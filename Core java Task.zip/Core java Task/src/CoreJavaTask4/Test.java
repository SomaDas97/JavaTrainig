package CoreJavaTask4;

public interface Test{ 
	
	double square(double x) ;
		
	}


