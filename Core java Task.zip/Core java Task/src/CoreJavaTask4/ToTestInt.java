package CoreJavaTask4;

public class ToTestInt {
	
	public static void main(String args []) {
		
		Arithmetical a = new Arithmetical();
		double x = a.square(22);
		
		System.out.println(x);
		
		
		
	}

}
