package CoreJavaTask3;

import java.util.*;

public class Result {
	
	
	public static void main(String args []) {
		
		Circle obj= new Circle();
		obj.area(3.0 , 2);
		obj.perimeter(5.0 , 4);
		
		Triangle s = new Triangle();
		s.area(6 , 9);
		s.perimeter( 4 ,8);
		
		
	}

}
