package OopsStart;

public class Bicycle {
	

}
