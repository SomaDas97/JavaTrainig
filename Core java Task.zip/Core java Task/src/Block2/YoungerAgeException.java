package Block2;

//import java.util.Arrays;
import java.util.Scanner;

 class YoungerAgeException extends RuntimeException {
                          YoungerAgeException(){
                        	     super();
                           }
 }

